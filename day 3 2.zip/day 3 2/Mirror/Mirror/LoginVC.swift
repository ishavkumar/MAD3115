//
//  LoginVC.swift
//  Mirror
//
//  Created by MacStudent on 2018-08-07.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class LoginVC: UIViewController {
    
    //MARK:- Outlets
    
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var txtPassword: UITextField!
    
    
    @IBOutlet weak var switchRemember: UISwitch!
    //MARK:- Actions
    
    @IBAction func btnSignup(_ sender: UIButton) {

        let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let SignupVC = mainSB.instantiateViewController(withIdentifier: "SignupScene")
        navigationController?.pushViewController(SignupVC, animated: true)
        
    }
    
    @IBAction func btnSignin(_ sender: UIButton) {
        
        if validateUser() {
            
            if switchRemember.isOn{
                
                UserDefaults.standard.set(txtEmail.text, forKey: "email" )
                UserDefaults.standard.set(txtPassword.text, forKey: "password")
               
                
            }else{
                
                UserDefaults.standard.removeObject(forKey: "email")
                UserDefaults.standard.removeObject(forKey: "password")
                
            }
//            performSegue(withIdentifier: "HomeIdentifier", sender: nil)
            
            let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let homeVC = mainSB.instantiateViewController(withIdentifier: "HomeScene")
//            self.present(homeVC, animated: true, completion: nil)
            navigationController?.pushViewController(homeVC, animated: true)
            
        } else {
            let infoAlert = UIAlertController(title: "Invalid User", message: "Incorrect credentials", preferredStyle: UIAlertControllerStyle.alert)
            infoAlert.addAction(UIAlertAction(title: "Retry", style: UIAlertActionStyle.default, handler: nil))
            self.present(infoAlert, animated: true, completion: nil)
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        if let email = UserDefaults.standard.string(forKey: "email"){
        txtEmail.text = email
        
        }
        
        if let password = UserDefaults.standard.value(forKey: "password"){
            
            txtPassword.text = password as? String
        }
        

    }
    
    func validateUser() -> Bool {
        if txtEmail.text == "test" && txtPassword.text == "test" {
            return true
        } else {
            return false
        }
    }

}

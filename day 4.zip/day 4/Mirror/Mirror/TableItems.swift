//
//  TableItems.swift
//  Mirror
//
//  Created by MacStudent on 2018-08-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class TableItems{
    
    static var Titles: [String] = ["Audio", "Video", "Web View", "calender", "Location", "Contacts"]
    
    static var subTitles: [String] = ["Soul Music", "Watch it Better", "World is Yours", "Time is not Yours", "Be Everywhere", "Saty Connected"]
    
    static var images: [String] = ["Audio", "Video", "Web", "Calender", "Location", "Contacts"]
}

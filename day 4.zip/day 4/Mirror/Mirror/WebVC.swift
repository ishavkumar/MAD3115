//
//  WebVC.swift
//  Mirror
//
//  Created by MacStudent on 2018-08-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import WebKit

class WebVC: UIViewController {

   
    @IBOutlet weak var WKWebView: WKWebView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        WKWebView.load(URLRequest(url: URL(string: "http://www.google.com")!))

        // Do any additional setup after loading the view.
    }


}

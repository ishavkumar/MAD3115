//
//  resultVC.swift
//  Game
//
//  Created by MacStudent on 2018-08-17.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class resultVC: NSObject {

}

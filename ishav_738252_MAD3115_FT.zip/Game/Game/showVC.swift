//
//  showVC.swift
//  Game
//
//  Created by MacStudent on 2018-08-17.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class showVC: UIViewController {

    @IBOutlet weak var lblWin: UILabel!
    
    
    
    @IBOutlet weak var lblLose: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lblWin.layer.cornerRadius = lblWin.frame.width/2
        lblWin.layer.cornerRadius = lblWin.frame.height/2
        
        
        
        
        lblLose.layer.cornerRadius = lblLose.frame.width/2
        lblLose.layer.cornerRadius = lblLose.frame.height/2
        
        
        
        lblWin.clipsToBounds = true
        lblLose.clipsToBounds = true
        
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

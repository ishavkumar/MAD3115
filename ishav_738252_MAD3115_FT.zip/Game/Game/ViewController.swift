import UIKit

import AVFoundation



var CountDownCustom = 10



class ViewController: UIViewController {
    
    
    
    var sound : AVAudioPlayer?
    var num : String = ""
    
    // var  CountDownCustom = 10
    
    @IBOutlet weak var txtAnswer: UITextField!
    
    
    @IBAction func btnCheck(_ sender: Any) {
        
        check()
        
    }
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        randomNum()
        
        
        
    }
            func winningSound() {
        
        let path = Bundle.main.path(forResource: "Win.wav", ofType:nil)!
                let url = URL(fileURLWithPath: path)
                do {
            sound = try AVAudioPlayer(contentsOf: url)
                        sound?.play()
            
        } catch {
            
            // couldn't load file :(
            
        }
        
        
        
    }
    
    
    
    func looseSound() {
        
        let path = Bundle.main.path(forResource: "Lost.wav", ofType:nil)!
        let url = URL(fileURLWithPath: path)
                              do {
            
            sound = try AVAudioPlayer(contentsOf: url)
                        sound?.play()
            
        } catch {
            
            // couldn't load file :(
            
        }
        
    }
    
    
    
    
    
    func randomNum()
        
    {
                num = String(Int(arc4random_uniform(100) + 1))
        
    }
    
    
    func check()
        
    {
                if num == (txtAnswer.text){
                        print("right  answer is \(num)")
                         answerRight()
            
        }
            
        else{
                    
            print(" right answer is \(num)")
             answerWrong()
            
        }
            }
    
    func answerRight()
        
    {
        
        let alert = UIAlertController(title: "Result", message: "Hurraahhh.. You won the game", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Play again!!", style: .default, handler:{(alert : UIAlertAction) in self.randomNum()}))
        alert.addAction(UIAlertAction(title: "Quit Game", style: UIAlertActionStyle.destructive, handler: { (alert : UIAlertAction) in
        self.quitGame()
            
        }))
        
        self.present(alert, animated: true, completion: nil)
        
        winningSound()
         CountDownCustom = 10
        
    }
    
    
    
    func answerWrong()
        
    {
        
        CountDownCustom = CountDownCustom - 1
        
        if CountDownCustom == 0
            
        {
            let alert = UIAlertController(title: "Result", message: "You lost the game..! \n Correct num is \(num)", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Play again!!", style: .default, handler:{(alert : UIAlertAction) in self.randomNum()}))
            alert.addAction(UIAlertAction(title: "Quit Game", style: UIAlertActionStyle.destructive, handler: { (alert : UIAlertAction) in
                
                self.quitGame()
                
            }))
            
            self.present(alert, animated: true, completion: nil)
            looseSound()
            CountDownCustom = 10
            
        }
            
        else{
            
            if num < txtAnswer.text!
                
            {
                let alert = UIAlertController(title: "Result", message: " Number is  too high. \n \(CountDownCustom) Attempts left ", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Keep Trying !", style: .default, handler: { (alert : UIAlertAction) in
                          self.txtAnswer.text = nil
                    
                }))
                alert.addAction(UIAlertAction(title: "Quit Game", style: UIAlertActionStyle.destructive, handler: { (alert : UIAlertAction) in
               
                   self.quitGame()
                    
                }))
                
                self.present(alert, animated: true, completion: nil)
                     }
                
            else
                
            {
                
                let alert = UIAlertController(title: "Alert", message: "number is too low. \n  \(CountDownCustom) Attempts left", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Keep trying !", style: .default, handler: { (alert : UIAlertAction) in
                    
                    self.txtAnswer.text = nil
                    
                }))
                
                alert.addAction(UIAlertAction(title: "Quit Game", style: UIAlertActionStyle.destructive, handler: { (alert : UIAlertAction) in
                    
                    self.quitGame()
                    
                }))
                
                self.present(alert, animated: true, completion: nil)
                
            }
            
        }
        
      
        
    }
    
      func quitGame() {
         let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
         let showVC = mainSB.instantiateViewController(withIdentifier: "showVC")
         self.navigationController?.pushViewController(showVC, animated: true)
        
    }
    
    
    
    
    
    
    
}

